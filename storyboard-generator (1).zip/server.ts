import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Shared lazy-loaded Gemini client
let _ai: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!_ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured. Please supply it in the physical application Secrets panel.");
    }
    _ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return _ai;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json({ limit: "15mb" }));

  // API Route: Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // API Route: Parse Script into Storyboard Scenes
  app.post("/api/parse-script", async (req, res) => {
    try {
      const { scriptText, stylePreference } = req.body;
      if (!scriptText || typeof scriptText !== "string" || scriptText.trim().length === 0) {
        return res.status(400).json({ error: "Script text is required and cannot be empty." });
      }

      const ai = getGenAI();
      const styleInstruction = stylePreference 
        ? `Ensure the visualDescription is optimized for generating images in ${stylePreference} style.`
        : "Optimize the prompts to produce clear, cinematic and highly descriptive images.";

      const prompt = `Analyze the following movie/animation script and decompose it into a chronological sequence of storyboard frames/scenes (at most 10-12 scenes for brevity, capturing major beats and camera shots).
For each scene, construct a clear scene setting titles, an extremely descriptive visual instruction for an image generation prompt, a transition style, any relevant dialogue or voiceover lines, and the duration.

${styleInstruction}

Script:
"""
${scriptText}
"""`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are a structural script supervisor and storyboarding artist. Your job is to extract key narrative beats and translate them into visual cues. Always respond strictly with a valid JSON array of scenes.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            description: "Array of chronological storyboard scenes",
            items: {
              type: Type.OBJECT,
              properties: {
                sceneNumber: { 
                  type: Type.INTEGER, 
                  description: "Chronological index of the scene starting from 1" 
                },
                title: { 
                  type: Type.STRING, 
                  description: "Compact scene title or setting name, e.g. INT. SUBWAY TRAIN - NIGHT" 
                },
                visualDescription: { 
                  type: Type.STRING, 
                  description: "A rich, descriptive prompt for generating the final illustration. Specify camera framing/angle (e.g. wide shot, slow zoom, extreme close-up), key characters, cinematic lighting (moody shadows, neon rim-light), and detailed environment. Avoid referencing meta-text like 'storyboard' or 'frame'." 
                },
                dialogue: { 
                  type: Type.STRING, 
                  description: "Key line of dialogue, narrator voiceover, or sound effect details for this shot." 
                },
                transition: { 
                  type: Type.STRING, 
                  description: "Framing or transitional direction, e.g., EXT. CLOSE UP, WIDE ESTABLISHING SHOT, MEDIUM SHOT, CUT TO, FADE IN" 
                },
                duration: { 
                  type: Type.STRING, 
                  description: "Expected shot duration on screen, e.g., 4s" 
                }
              },
              required: ["sceneNumber", "title", "visualDescription"]
            }
          }
        }
      });

      const resultText = response.text;
      if (!resultText) {
        throw new Error("Received empty response from the script parser.");
      }

      // Parse JSON and return to client
      const scenes = JSON.parse(resultText);
      res.json({ scenes });

    } catch (error: any) {
      console.error("Error parsing script:", error);
      res.status(500).json({ error: error?.message || "An unexpected error occurred while parsing your script." });
    }
  });

  // API Route: Generate individual Storyboard Image
  app.post("/api/generate-storyboard-image", async (req, res) => {
    try {
      const { prompt, style, aspectRatio = "16:9", imageSize = "1K" } = req.body;
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "Scene visual description prompt is empty or invalid." });
      }

      const ai = getGenAI();

      // Incorporate artistic style instructions directly inside the prompt
      let styledPrompt = prompt;
      if (style) {
        styledPrompt = `${style} style illustration, high-fidelity: ${prompt}`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: {
          parts: [{ text: styledPrompt }]
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any
          }
        }
      });

      let base64Data = "";
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            base64Data = part.inlineData.data;
            break;
          }
        }
      }

      if (!base64Data) {
        // Try fallback to search text response errors or helpful feedback
        const textParts = response.candidates?.[0]?.content?.parts
          ?.filter(p => p.text)
          ?.map(p => p.text)
          ?.join(" ") || "";
        throw new Error(textParts || "Failed to generate visual storyboard image. Please revise the description and try again.");
      }

      res.json({
        imageUrl: `data:image/png;base64,${base64Data}`
      });

    } catch (error: any) {
      console.error("Error generating storyboard image:", error);
      res.status(500).json({ error: error?.message || "An error occurred during image generation." });
    }
  });

  // API Route: Creative Director Chat
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Chat message history is missing or invalid." });
      }

      const ai = getGenAI();
      const formattedContents = messages.map(m => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.text }]
      }));

      const systemInstruction = 
        `You are a professional Creative Storyboard Director and Script Consultant. Your tone is supportive, creative, and insightful. 
        You give specific suggestions on camera angles, scene pacing, lighting, or scripting to improve emotional resonance, and you advise on how to better frame visual prompts.
        Keep your advice relatively concise and actionable so the user can easily adjust their visual descriptions.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: formattedContents,
        config: {
          systemInstruction
        }
      });

      res.json({
        text: response.text || "I was unable to formulate a response. Let me know if we can try adjusting this scene step-by-step!"
      });

    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: error?.message || "An unexpected error occurred in your conversation session." });
    }
  });

  // Vite middleware for client asset compilation & SPA fallback
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server successfully started. Running on port ${PORT}`);
  });
}

startServer();

import React, { useState, useEffect } from 'react';
import { StoryboardScene, ChatMessage, VisualStyle, ImageSize, AspectRatio } from './types';
import ScriptUpload from './components/ScriptUpload';
import StoryboardView from './components/StoryboardView';
import DirectorChat from './components/DirectorChat';
import LaLibertadMap from './components/LaLibertadMap';
import { 
  Film, 
  Trash2, 
  HelpCircle, 
  Sparkles, 
  Clapperboard, 
  ArrowRight, 
  BookOpen, 
  AlertCircle,
  Map,
  Compass
} from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<'storyboard' | 'lalibertad'>('lalibertad');
  const [scenes, setScenes] = useState<StoryboardScene[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [visualStyle, setVisualStyle] = useState<VisualStyle>('Cinematic');
  const [imageSize, setImageSize] = useState<ImageSize>('1K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  
  // Loading & generation statuses
  const [isParsing, setIsParsing] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Restore state from localStorage on load representation
  useEffect(() => {
    try {
      const storedScenes = localStorage.getItem('storyboard_scenes');
      if (storedScenes) {
        setScenes(JSON.parse(storedScenes));
      }
      
      const storedChat = localStorage.getItem('storyboard_chat');
      if (storedChat) {
        setChatMessages(JSON.parse(storedChat));
      }

      const storedStyle = localStorage.getItem('storyboard_style');
      if (storedStyle) {
        setVisualStyle(storedStyle as VisualStyle);
      }

      const storedSize = localStorage.getItem('storyboard_size');
      if (storedSize) {
        setImageSize(storedSize as ImageSize);
      }

      const storedRatio = localStorage.getItem('storyboard_ratio');
      if (storedRatio) {
        setAspectRatio(storedRatio as AspectRatio);
      }
    } catch (e) {
      console.error("Failed to restore app state from localStorage", e);
    }
  }, []);

  // Sync helpers to keep local storage hydrated
  const saveScenes = (updatedScenes: StoryboardScene[]) => {
    setScenes(updatedScenes);
    try {
      localStorage.setItem('storyboard_scenes', JSON.stringify(updatedScenes));
    } catch (e) {
      console.error(e);
    }
  };

  const saveChatMessages = (updatedChat: ChatMessage[]) => {
    setChatMessages(updatedChat);
    try {
      localStorage.setItem('storyboard_chat', JSON.stringify(updatedChat));
    } catch (e) {
      console.error(e);
    }
  };

  // Trigger Backend Script Parsing
  const handleParseScript = async (
    scriptText: string, 
    style: VisualStyle, 
    size: ImageSize, 
    ratio: AspectRatio
  ) => {
    setGlobalError(null);
    setIsParsing(true);
    
    // Save configurations
    setVisualStyle(style);
    setImageSize(size);
    setAspectRatio(ratio);
    localStorage.setItem('storyboard_style', style);
    localStorage.setItem('storyboard_size', size);
    localStorage.setItem('storyboard_ratio', ratio);

    try {
      const response = await fetch('/api/parse-script', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scriptText, stylePreference: style })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Server failed to compile script scenes.");
      }

      if (data.scenes && Array.isArray(data.scenes)) {
        // Map elements into formal structure
        const formalScenes: StoryboardScene[] = data.scenes.map((scene: any, index: number) => ({
          id: `scene-${Date.now()}-${index}`,
          sceneNumber: scene.sceneNumber || (index + 1),
          title: scene.title || `Scene ${index + 1}`,
          visualDescription: scene.visualDescription || "",
          dialogue: scene.dialogue || "",
          duration: scene.duration || "5s",
          transition: scene.transition || "CUT TO:",
          imageUrl: undefined,
          isGenerating: false,
          error: undefined
        }));

        saveScenes(formalScenes);
      } else {
        throw new Error("Invalid response format received from compiler.");
      }
    } catch (error: any) {
      console.error("Parsing error:", error);
      setGlobalError(error?.message || "Connection timed out or failed to reach the script interpreter.");
    } finally {
      setIsParsing(false);
    }
  };

  // Generate Image for a SINGLE Storyboard Scene
  const handleGenerateImageSingle = async (sceneId: string, customPrompt: string) => {
    // Locate scene, update status
    const updated = scenes.map(s => {
      if (s.id === sceneId) {
        return { ...s, isGenerating: true, error: undefined };
      }
      return s;
    });
    setScenes(updated);

    try {
      const response = await fetch('/api/generate-storyboard-image', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: customPrompt,
          style: visualStyle,
          aspectRatio,
          imageSize
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to generate storyboard illustration.");
      }

      const finalScenes = scenes.map(s => {
        if (s.id === sceneId) {
          return { ...s, imageUrl: data.imageUrl, isGenerating: false, error: undefined };
        }
        return s;
      });
      saveScenes(finalScenes);

    } catch (error: any) {
      console.error("Single image error:", error);
      const finalScenes = scenes.map(s => {
        if (s.id === sceneId) {
          return { ...s, isGenerating: false, error: error?.message || "Illustration failed to compile." };
        }
        return s;
      });
      saveScenes(finalScenes);
    }
  };

  // Generate ALL scenes sequentially to show stunning real-time popping up of illustrations!
  const handleGenerateAll = async () => {
    if (isGeneratingAll) return;
    setIsGeneratingAll(true);

    try {
      // Loop sequentially
      for (const scene of scenes) {
        // Skip scenes that already have illustrations
        if (scene.imageUrl) continue;

        // Perform request
        await handleGenerateImageSingle(scene.id, scene.visualDescription);
      }
    } catch (error) {
      console.error("Batch generation exception", error);
    } finally {
      setIsGeneratingAll(false);
    }
  };

  // Storyboard update handlers
  const handleUpdateScenePrompt = (id: string, updatedPrompt: string) => {
    const updated = scenes.map(s => s.id === id ? { ...s, visualDescription: updatedPrompt } : s);
    saveScenes(updated);
  };

  const handleUpdateSceneTitle = (id: string, title: string) => {
    const updated = scenes.map(s => s.id === id ? { ...s, title } : s);
    saveScenes(updated);
  };

  const handleUpdateSceneDialogue = (id: string, dialogue: string) => {
    const updated = scenes.map(s => s.id === id ? { ...s, dialogue } : s);
    saveScenes(updated);
  };

  // Send message to the Director consultancy chatbot
  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newHistory = [...chatMessages, userMsg];
    saveChatMessages(newHistory);
    setIsChatLoading(true);

    try {
      // We send history to endpoint
      const response = await fetch('/api/chat', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newHistory })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Director was interrupted or unavailable.");
      }

      const modelMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      saveChatMessages([...newHistory, modelMsg]);

    } catch (error: any) {
      console.error(error);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: `Error: ${error?.message || "I had trouble rendering that idea. Please check that your Gemini details are fully set up in AI Studio Secrets panel."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      saveChatMessages([...newHistory, errMsg]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Clear local grid completely
  const handleClearStoryboard = () => {
    if (window.confirm("Are you sure you want to clear your current storyboard grid? This cannot be undone.")) {
      saveScenes([]);
      setGlobalError(null);
    }
  };

  const handleClearChatHistory = () => {
    saveChatMessages([]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Decorative Cinematic Background Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Structural Navbar */}
      <nav className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-tr from-amber-600 to-amber-500 rounded-xl relative shadow-md">
              <Clapperboard className="w-5 h-5 text-slate-950 font-bold" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-sky-500 rounded-full animate-ping" />
            </div>
            <div>
              <h1 className="text-base font-bold text-zinc-100 tracking-tight flex items-center gap-1.5 uppercase tracking-wide">
                Storyboard Studio
              </h1>
              <p className="text-[10px] text-slate-500 font-medium">Gemini 3-Pro Visual Production Kit</p>
            </div>
          </div>

          {/* Interactive Workspace Toggle */}
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 self-start md:self-auto shadow-inner">
            <button
              onClick={() => setCurrentView('lalibertad')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
                currentView === 'lalibertad'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-zinc-200'
              }`}
            >
              <Map className="w-3.5 h-3.5" />
              <span>Vacaciones La Libertad</span>
            </button>
            <button
              onClick={() => setCurrentView('storyboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
                currentView === 'storyboard'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-zinc-200'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Storyboard Generator</span>
            </button>
          </div>

          <div className="flex items-center gap-3 self-end md:self-auto">
            {scenes.length > 0 && currentView === 'storyboard' && (
              <button
                onClick={handleClearStoryboard}
                className="text-xs px-3.5 py-2 bg-slate-900 hover:bg-rose-500/10 hover:text-rose-400 border border-slate-800 text-slate-400 rounded-xl transition-all flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Reset Storyboard</span>
              </button>
            )}
            <div className="hidden md:flex items-center gap-1.5 py-1 px-2.5 bg-slate-900 border border-slate-800 rounded-full">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Active Studio Session</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Dashboard Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
        <div className="lg:col-span-2 space-y-6 flex flex-col">
          {/* General Alert */}
          {globalError && (
            <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-450 rounded-2xl flex items-start gap-3 shadow-md">
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-sm font-semibold">Generative Engine Warning</h4>
                <p className="text-xs text-rose-300 leading-tight">{globalError}</p>
              </div>
            </div>
          )}

          {currentView === 'lalibertad' ? (
            <LaLibertadMap />
          ) : (
            <>
              {/* Script Input Screen */}
              <ScriptUpload 
                onParseScript={handleParseScript} 
                isLoading={isParsing} 
              />

              {/* Storyboard View Screen */}
              <StoryboardView
                scenes={scenes}
                onGenerateImageSingle={handleGenerateImageSingle}
                onGenerateAll={handleGenerateAll}
                isGeneratingAll={isGeneratingAll}
                imageSize={imageSize}
                aspectRatio={aspectRatio}
                visualStyle={visualStyle}
                onUpdateScenePrompt={handleUpdateScenePrompt}
                onUpdateSceneTitle={handleUpdateSceneTitle}
                onUpdateSceneDialogue={handleUpdateSceneDialogue}
              />
            </>
          )}
        </div>

        {/* Side panel Director Chat Interface */}
        <div className="lg:col-span-1 h-full lg:sticky lg:top-[85px] self-start pb-6">
          <DirectorChat
            messages={chatMessages}
            onSendMessage={handleSendMessage}
            isChatLoading={isChatLoading}
            onClearHistory={handleClearChatHistory}
          />
        </div>
      </main>

      {/* Humble Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-6 text-center">
        <p className="text-xs text-slate-600">
          Storyboard Studio & Vacation Planner • Crafted using high-performance Leaflet route rendering and Gemini visual assistants.
        </p>
      </footer>
    </div>
  );
}

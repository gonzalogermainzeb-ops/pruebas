export interface StoryboardScene {
  id: string;
  sceneNumber: number;
  title: string;
  visualDescription: string;
  dialogue?: string;
  duration?: string;
  transition?: string;
  imageUrl?: string;
  isGenerating?: boolean;
  error?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '16:9' | '1:1' | '4:3' | '3:2' | '9:16';
export type VisualStyle = 'Cinematic' | 'Anime Sketch' | 'Comic Book Line-Art' | '3D Render' | 'Watercolor' | 'Moody Noir';

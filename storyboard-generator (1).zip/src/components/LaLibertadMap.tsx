import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { VERTICES, TOURIST_SPOTS, HOTELS } from '../data/laLibertadData';
import { RUTA_BLUE, RUTA_PURPLE } from '../data/routesData';
import { Map, Navigation2, Compass, Home, MapPin, Eye, Zap, RefreshCw } from 'lucide-react';

export default function LaLibertadMap() {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const polylineGroupRef = useRef<L.FeatureGroup | null>(null);

  const [activeTab, setActiveTab] = useState<'all' | 'hotels' | 'tourist'>('all');
  const [liveLocationText, setLiveLocationText] = useState('Centrado en La Libertad');

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // 1. Initialize map
    const map = L.map(mapContainerRef.current, {
      zoomControl: false,
    });
    mapRef.current = map;

    // 2. Add high contrast dark tile layer or cozy street view map
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    // Add scale bar
    L.control.scale({ position: 'bottomright' }).addTo(map);

    // 3. Render Department of La Libertad boundary polygon
    const departmentPolygon = L.polygon(VERTICES, {
      color: '#ef4444',
      weight: 2,
      fillColor: '#fbbf24',
      fillOpacity: 0.15,
    }).addTo(map);

    departmentPolygon.bindPopup(
      `<strong>📍 DEPARTAMENTO DE LA LIBERTAD</strong><br/>
       <span class="text-xs text-slate-400">Capital: Trujillo<br/>Zona turística y norteña de historia precolombina y playas hermosas.</span>`
    );

    // Create feature group for active bounds discovery
    const routeGroup = L.featureGroup().addTo(map);
    polylineGroupRef.current = routeGroup;

    // 4. Render Route 1 (Top Blue Route)
    // White background outline for highway style
    L.polyline(RUTA_BLUE, {
      color: '#FFFFFF',
      weight: 10,
      opacity: 0.9,
      lineCap: 'round',
      lineJoin: 'round',
    }).addTo(routeGroup);

    // Dynamic blue route line
    const blueLine = L.polyline(RUTA_BLUE, {
      color: '#ffb703', // yellow accent boundary
      weight: 6,
      opacity: 1,
      lineCap: 'round',
      lineJoin: 'round',
    }).addTo(routeGroup);

    // Add another pure active blue line with our CSS class name to create the flowing flow!
    L.polyline(RUTA_BLUE, {
      color: '#0284c7', // Slate sky blue
      weight: 6,
      opacity: 1,
      lineCap: 'round',
      lineJoin: 'round',
      className: 'animated-blue-route',
    }).addTo(routeGroup);

    // 5. Render Route 2 (Bottom Purple Route)
    // White background outline for highway style
    L.polyline(RUTA_PURPLE, {
      color: '#FFFFFF',
      weight: 10,
      opacity: 0.9,
      lineCap: 'round',
      lineJoin: 'round',
    }).addTo(routeGroup);

    // Purple dynamic path
    L.polyline(RUTA_PURPLE, {
      color: '#a855f7', // Purple/Violent flow
      weight: 6,
      opacity: 1,
      lineCap: 'round',
      lineJoin: 'round',
      className: 'animated-purple-route',
    }).addTo(routeGroup);

    // 6. Custom Markers
    // Render Hotels
    HOTELS.forEach((hotel) => {
      const hotelIcon = L.divIcon({
        className: 'bg-transparent',
        html: `
          <div class="flex flex-col items-center justify-center">
            <div class="p-1 px-2 bg-emerald-600 text-slate-100 text-[9px] font-bold rounded-lg shadow-md border border-emerald-400 whitespace-nowrap animate-bounce flex items-center gap-1">
              🏨 ${hotel.name}
            </div>
            <div class="w-3 h-3 bg-emerald-600 rounded-full border-2 border-slate-900 shadow-md"></div>
          </div>
        `,
        iconSize: [100, 45],
        iconAnchor: [50, 45],
      });

      const hMarker = L.marker(hotel.coords as [number, number], { icon: hotelIcon }).addTo(map);
      hMarker.bindPopup(`
        <div class="p-1">
          <strong class="text-sm font-semibold">${hotel.name}</strong><br/>
          <span class="text-[11px] text-emerald-500 font-semibold">${hotel.type}</span><br/>
          <p class="text-xs mt-1 text-slate-350">${hotel.info}</p>
        </div>
      `, { className: 'custom-popup' });

      // Live bind permanent interactive tooltips
      hMarker.bindTooltip(`
        <div class="text-[10px] leading-tight">
          <strong>${hotel.name}</strong><br/>
          <span class="text-slate-405">${hotel.type}</span>
        </div>
      `, {
        direction: 'top',
        className: 'custom-tooltip',
        opacity: 0.9
      });
    });

    // Render Tourist Spots/Destinations
    TOURIST_SPOTS.forEach((spot) => {
      const spotIcon = L.divIcon({
        className: 'bg-transparent',
        html: `
          <div class="flex flex-col items-center justify-center">
            <div class="p-1 px-2 bg-amber-500 text-slate-950 text-[9px] font-bold rounded-lg shadow-md border border-amber-300 whitespace-nowrap flex items-center gap-1">
              🌟 ${spot.name}
            </div>
            <div class="w-3 h-3 bg-amber-500 rounded-full border-2 border-slate-900 shadow-md"></div>
          </div>
        `,
        iconSize: [90, 40],
        iconAnchor: [45, 40],
      });

      const sMarker = L.marker(spot.coords as [number, number], { icon: spotIcon }).addTo(map);
      sMarker.bindPopup(`
        <div class="p-1 max-w-[200px]">
          <strong class="text-amber-500 font-semibold text-xs uppercase tracking-wider">Atractivo Turístico</strong><br/>
          <strong class="text-sm font-bold text-slate-100">${spot.name}</strong><br/>
          <p class="text-xs mt-1 text-slate-300 leading-tight">${spot.desc}</p>
        </div>
      `, { className: 'custom-popup' });
    });

    // Set initial bounds to encompass the animated routes
    map.fitBounds(routeGroup.getBounds(), {
      padding: [50, 50],
      maxZoom: 14
    });

    // Cleanup on destroy
    return () => {
      map.remove();
    };
  }, []);

  // Utility flyers
  const flyToCoords = (coords: [number, number], zoom: number, label: string) => {
    if (!mapRef.current) return;
    mapRef.current.flyTo(coords, zoom, {
      duration: 1.8,
      easeLinearity: 0.25,
    });
    setLiveLocationText(label);
  };

  const resetToRoutes = () => {
    if (!mapRef.current || !polylineGroupRef.current) return;
    mapRef.current.flyToBounds(polylineGroupRef.current.getBounds(), {
      padding: [40, 40],
      duration: 1.5,
    });
    setLiveLocationText('Rutas Turísticas de La Libertad');
  };

  return (
    <div id="la-libertad-map-view" className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col h-[700px] shadow-2xl relative">
      
      {/* Dynamic Header */}
      <div className="bg-slate-950 px-6 py-4 border-b border-slate-850 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-500/10 text-sky-400 rounded-xl relative">
            <Map className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm md:text-base font-bold text-zinc-100 uppercase tracking-wide">
              Mapa Turístico La Libertad
            </h2>
            <p className="text-xs text-slate-500 flex items-center gap-1.5 leading-none mt-1">
              <Compass className="w-3.5 h-3.5 text-amber-500 animate-spin" />
              <span>{liveLocationText}</span>
            </p>
          </div>
        </div>

        {/* Quick Location Nav Rail */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={resetToRoutes}
            className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-sky-500/40 text-sky-400 font-semibold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Centrar Rutas</span>
          </button>
          <button
            onClick={() => flyToCoords([-8.083384, -79.119367], 15, 'Balneario de Huanchaco')}
            className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 text-amber-500 font-semibold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center gap-1"
          >
            <MapPin className="w-3 h-3" />
            <span>Huanchaco</span>
          </button>
          <button
            onClick={() => flyToCoords([-8.100367, -79.066059], 15, 'Complejo Arqueológico Chan Chan')}
            className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 text-amber-500 font-semibold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center gap-1"
          >
            <MapPin className="w-3 h-3" />
            <span>Chan Chan</span>
          </button>
        </div>
      </div>

      {/* Map DOM Iframe Container */}
      <div className="flex-1 w-full bg-slate-950 relative">
        <div 
          ref={mapContainerRef} 
          className="absolute inset-0 z-10 w-full h-full"
        />

        {/* Floating Custom HUD Legend */}
        <div className="absolute bottom-4 left-4 z-20 bg-slate-950/95 border border-slate-800 p-4 rounded-xl shadow-xl max-w-xs space-y-3 backdrop-blur-md">
          <div className="flex items-center gap-2 border-b border-slate-850 pb-2">
            <Zap className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">Leyenda Activa</span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-3 h-1 bg-sky-500 rounded-full inline-block animate-pulse" />
                Ruta Arriba (Navegación)
              </span>
              <span className="text-sky-400 font-bold uppercase tracking-widest text-[9px] animate-pulse">Fluido Azul</span>
            </div>

            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-3 h-1 bg-purple-500 rounded-full inline-block animate-pulse" />
                Ruta Abajo (Gastronómica)
              </span>
              <span className="text-purple-400 font-bold uppercase tracking-widest text-[9px] animate-pulse">Fluido Morado</span>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 bg-emerald-500 rounded-full inline-block animate-ping" />
                Hoteles Seleccionados
              </span>
              <span className="text-emerald-500 text-[10px] font-semibold">Interactivos</span>
            </div>

            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 bg-amber-500 rounded-full inline-block" />
                Atractivos Históricos
              </span>
              <span className="text-amber-500 text-[10px] font-semibold">Tumbas & Templos</span>
            </div>
          </div>
        </div>

        {/* Floating Quick Action Box */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2 bg-slate-950/90 border border-slate-800 p-2.5 rounded-xl backdrop-blur-md">
          <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-2 pb-1 border-b border-slate-850">Giras de Vuelo</span>
          <button 
            onClick={() => flyToCoords([-8.110955, -79.028971], 17, 'Costa del Sol Trujillo')}
            className="text-left text-[11px] bg-slate-900 hover:bg-slate-850 text-slate-300 py-1.5 px-3 rounded-md transition-all font-medium flex items-center justify-between gap-3"
          >
            <span>Hotel Costa del Sol</span>
            <ArrowRightIcon className="w-3 h-3 text-sky-400" />
          </button>
          <button 
            onClick={() => flyToCoords([-8.131838, -78.994589], 16, 'Huacas de Moche')}
            className="text-left text-[11px] bg-slate-900 hover:bg-slate-850 text-slate-300 py-1.5 px-3 rounded-md transition-all font-medium flex items-center justify-between gap-3"
          >
            <span>Huacas Sol y Luna</span>
            <ArrowRightIcon className="w-3 h-3 text-amber-500" />
          </button>
          <button 
            onClick={() => flyToCoords([-7.914205, -79.303675], 16, 'Magdalena de Cao - El Brujo')}
            className="text-left text-[11px] bg-slate-900 hover:bg-slate-850 text-slate-300 py-1.5 px-3 rounded-md transition-all font-medium flex items-center justify-between gap-3"
          >
            <span>Complejo El Brujo</span>
            <ArrowRightIcon className="w-3 h-3 text-amber-500" />
          </button>
        </div>
      </div>
    </div>
  );
}

function ArrowRightIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
    </svg>
  );
}

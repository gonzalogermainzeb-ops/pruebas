import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { Video, Send, Loader2, Sparkles, AlertCircle, HelpCircle } from 'lucide-react';

interface DirectorChatProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  isChatLoading: boolean;
  onClearHistory: () => void;
}

const PRESETS = [
  "How can I make the opening scene more mysterious?",
  "Suggest cinematic lighting for a dramatic emotional beat.",
  "What camera angles work best for high-speed action?",
  "Recommend a color palette representing hope and recovery."
];

export default function DirectorChat({
  messages,
  onSendMessage,
  isChatLoading,
  onClearHistory
}: DirectorChatProps) {
  const [inputText, setInputText] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isChatLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isChatLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handlePresetClick = (preset: string) => {
    if (isChatLoading) return;
    onSendMessage(preset);
  };

  return (
    <div id="director-chat-panel" className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[650px] lg:h-full relative overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-zinc-100 flex items-center gap-1.5 text-sm md:text-base">
              Director's Sandbox
            </h3>
            <p className="text-xs text-slate-500">Storyboard Coach & Creative Consultant</p>
          </div>
        </div>
        {messages.length > 0 && (
          <button 
            onClick={onClearHistory}
            className="text-xs px-2.5 py-1 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-md transition-colors"
          >
            Clear Sandbox
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-6">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-full text-amber-500/80 animate-pulse">
              <Sparkles className="w-8 h-8" />
            </div>
            <div className="max-w-xs space-y-2">
              <h4 className="text-sm font-semibold text-zinc-300">Consult your Director</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Need advice on shot composition, lighting adjustments, mood boards, or dramatic structure? Tap a prompt or type below!
              </p>
            </div>
            
            {/* Presets */}
            <div className="grid grid-cols-1 gap-2 w-full max-w-sm pt-2">
              {PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handlePresetClick(preset)}
                  className="text-left text-xs bg-slate-950 hover:bg-slate-850 hover:border-amber-500/40 text-slate-300 p-3 rounded-xl border border-slate-800 transition-all duration-200"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[85%] ${
                  msg.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
                }`}
              >
                <div
                  className={`p-3.5 rounded-2xl text-xs md:text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-amber-600 text-slate-950 rounded-br-none font-medium'
                      : 'bg-slate-950 text-zinc-300 border border-slate-800 rounded-bl-none'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">
                  {msg.role === 'user' ? 'You' : 'Creative Director'} • {msg.timestamp}
                </span>
              </div>
            ))}

            {isChatLoading && (
              <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-850 mr-auto max-w-[85%]">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-500" />
                <span>Director is analyzing script potential...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-3 border-t border-slate-800 bg-slate-950 flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask Director for scene tips..."
          className="flex-1 bg-slate-900 border border-slate-800 focus:border-amber-500/50 rounded-xl px-3 py-2 text-xs md:text-sm text-zinc-100 outline-none placeholder:text-slate-500"
          disabled={isChatLoading}
        />
        <button
          type="submit"
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 p-2.5 rounded-xl transition-all font-semibold flex items-center justify-center text-xs md:text-sm disabled:opacity-50"
          disabled={!inputText.trim() || isChatLoading}
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}

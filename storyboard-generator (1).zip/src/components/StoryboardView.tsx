import React from 'react';
import { StoryboardScene, ImageSize, AspectRatio, VisualStyle } from '../types';
import { Play, RotateCw, Image as ImageIcon, CheckCircle, AlertTriangle, Loader2, Sparkles, Clock, Compass } from 'lucide-react';

interface StoryboardViewProps {
  scenes: StoryboardScene[];
  onGenerateImageSingle: (sceneId: string, customPrompt: string) => Promise<void>;
  onGenerateAll: () => Promise<void>;
  isGeneratingAll: boolean;
  imageSize: ImageSize;
  aspectRatio: AspectRatio;
  visualStyle: VisualStyle;
  onUpdateScenePrompt: (sceneId: string, prompt: string) => void;
  onUpdateSceneTitle: (sceneId: string, title: string) => void;
  onUpdateSceneDialogue: (sceneId: string, dialogue: string) => void;
}

export default function StoryboardView({
  scenes,
  onGenerateImageSingle,
  onGenerateAll,
  isGeneratingAll,
  imageSize,
  aspectRatio,
  visualStyle,
  onUpdateScenePrompt,
  onUpdateSceneTitle,
  onUpdateSceneDialogue
}: StoryboardViewProps) {
  
  const completedCount = scenes.filter(s => s.imageUrl).length;
  const isGeneratingSome = scenes.some(s => s.isGenerating);

  // Aspect ratio helper CSS representation for the preview boxes
  const getAspectRatioClass = (ratio: AspectRatio) => {
    switch (ratio) {
      case '16:9': return 'aspect-video';
      case '9:16': return 'aspect-[9/16] max-h-72 object-cover';
      case '4:3': return 'aspect-[4/3]';
      case '3:2': return 'aspect-[3/2]';
      case '1:1': 
      default:
        return 'aspect-square';
    }
  };

  return (
    <div id="storyboard-view-section" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md">
        <div>
          <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <Compass className="w-5 h-5 text-amber-500" />
            Analyzed Visual Storyboard
          </h2>
          <p className="text-xs text-slate-500">
            {scenes.length} Scenes Extracted • Style: <span className="text-amber-500 font-medium">{visualStyle}</span> • Format: <span className="text-slate-350">{imageSize} ({aspectRatio})</span>
          </p>
        </div>

        {scenes.length > 0 && (
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-xs text-slate-400">Progress: {completedCount}/{scenes.length} Frames</p>
              <div className="w-24 bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1 border border-slate-800">
                <div 
                  className="bg-amber-500 h-full transition-all duration-300"
                  style={{ width: `${(completedCount / scenes.length) * 100}%` }}
                />
              </div>
            </div>

            <button
              id="generate-full-button"
              onClick={onGenerateAll}
              disabled={isGeneratingAll || isGeneratingSome}
              className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold py-2.5 px-5 rounded-xl text-xs md:text-sm transition-all shadow-md flex items-center gap-2 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGeneratingAll ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Casting Whole Grid...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Generate All Frames</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {scenes.length === 0 ? (
        <div className="border-2 border-dashed border-slate-800 rounded-3xl p-12 text-center bg-slate-950/20">
          <div className="max-w-sm mx-auto space-y-4">
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl w-14 h-14 mx-auto flex items-center justify-center text-slate-600">
              <ImageIcon className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-300">Storyboard Empty</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Paste your movie script above and submit, or choose one of our Quick-Start sample libraries to see a beautiful generated storyboard grid!
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
          {scenes.map((scene) => (
            <div 
              key={scene.id} 
              className="bg-slate-900 border border-slate-850 rounded-2xl overflow-hidden flex flex-col hover:border-slate-700 transition-all duration-300 shadow-lg group"
            >
              {/* Card Header */}
              <div className="px-4 py-3 bg-slate-950 border-b border-slate-850 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded-full uppercase">
                    Shot {scene.sceneNumber}
                  </span>
                  {scene.transition && (
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-medium">
                      {scene.transition}
                    </span>
                  )}
                </div>
                {scene.duration && (
                  <span className="text-[10px] text-slate-500 capitalize flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3 text-slate-600" />
                    {scene.duration}
                  </span>
                )}
              </div>

              {/* Graphic Showcase Section */}
              <div className="relative bg-slate-950 flex items-center justify-center overflow-hidden border-b border-slate-850">
                <div className={`w-full ${getAspectRatioClass(aspectRatio)} relative flex items-center justify-center transition-all bg-slate-950`}>
                  {scene.imageUrl ? (
                    <img
                      src={scene.imageUrl}
                      alt={scene.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                  ) : scene.isGenerating ? (
                    <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-4 text-center space-y-3">
                      <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-zinc-300">Generating Storyboard Illustration...</p>
                        <p className="text-[10px] text-slate-500 font-mono">Size: {imageSize}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-6 text-center space-y-4">
                      <div className="p-3 bg-slate-900 border border-slate-850 text-slate-600 rounded-full">
                        <ImageIcon className="w-6 h-6" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-zinc-400">Illustration Pending</p>
                        <p className="text-[10px] text-slate-600 max-w-[200px] mx-auto">Click generate below to materialize the scene</p>
                      </div>
                    </div>
                  )}

                  {/* Complete Indicator */}
                  {scene.imageUrl && (
                    <div className="absolute top-3 right-3 p-1.5 bg-emerald-500/10 text-emerald-500 rounded-full backdrop-blur-md border border-emerald-500/20">
                      <CheckCircle className="w-4 h-4" />
                    </div>
                  )}
                </div>
              </div>

              {/* Card Meta & Control Panel */}
              <div className="p-5 flex-1 flex flex-col space-y-4 justify-between bg-slate-900">
                <div className="space-y-3">
                  {/* Editable Title */}
                  <input
                    type="text"
                    value={scene.title}
                    onChange={(e) => onUpdateSceneTitle(scene.id, e.target.value)}
                    className="w-full text-sm font-semibold text-zinc-100 bg-transparent hover:bg-slate-850 hover:border-slate-800 px-1 py-0.5 rounded border border-transparent focus:border-amber-500/50 outline-none transition-all"
                    placeholder="Enter short scene name..."
                  />

                  {/* Editable Prompt */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide">
                      Visual Illustration Prompt (Editable)
                    </label>
                    <textarea
                      rows={3}
                      value={scene.visualDescription}
                      onChange={(e) => onUpdateScenePrompt(scene.id, e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-zinc-300 outline-none focus:border-amber-500/40 resize-none leading-relaxed transition-all placeholder:text-slate-700"
                      placeholder="Prompt description representing the physical action..."
                    />
                  </div>

                  {/* Dialogue Input */}
                  <div className="space-y-1 bg-slate-950/30 p-2.5 rounded-xl border border-slate-850">
                    <label className="text-[9px] font-semibold text-slate-500 uppercase tracking-wide block">
                      Script Voiceover / Dialogue (Editable)
                    </label>
                    <input
                      type="text"
                      value={scene.dialogue || ''}
                      onChange={(e) => onUpdateSceneDialogue(scene.id, e.target.value)}
                      className="w-full bg-transparent text-xs text-zinc-400 italic placeholder:text-slate-700 outline-none focus:text-zinc-200"
                      placeholder="No dialogue or narration in this storyboard beat..."
                    />
                  </div>
                </div>

                {/* Error Banner */}
                {scene.error && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl flex items-start gap-2 text-xs">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                    <p className="leading-tight">{scene.error}</p>
                  </div>
                )}

                {/* Trigger Action */}
                <button
                  type="button"
                  onClick={() => onGenerateImageSingle(scene.id, scene.visualDescription)}
                  disabled={scene.isGenerating || isGeneratingAll}
                  className={`w-full py-2.5 px-4 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all text-xs ${
                    scene.imageUrl 
                      ? 'bg-slate-950 hover:bg-slate-1000 text-slate-300 border border-slate-800' 
                      : 'bg-zinc-100 hover:bg-zinc-200 text-slate-950'
                  } disabled:opacity-40 disabled:cursor-not-allowed`}
                >
                  {scene.isGenerating ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Generating Frame...</span>
                    </>
                  ) : scene.imageUrl ? (
                    <>
                      <RotateCw className="w-3.5 h-3.5" />
                      <span>Re-Generate Frame</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      <span>Generate Illustration</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

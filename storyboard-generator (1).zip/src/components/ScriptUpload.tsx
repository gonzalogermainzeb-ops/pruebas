import React, { useState } from 'react';
import { VisualStyle, ImageSize, AspectRatio } from '../types';
import { Upload, Film, ChevronRight, FileText, Sparkles, Sliders } from 'lucide-react';

interface ScriptUploadProps {
  onParseScript: (scriptText: string, style: VisualStyle, size: ImageSize, ratio: AspectRatio) => Promise<void>;
  isLoading: boolean;
}

const SAMPLE_SCRIPTS = [
  {
    title: "The Neon Heist (Cyberpunk)",
    style: "Cinematic" as VisualStyle,
    text: `EXT. RAIN-SLICKED ROOFTOP - NIGHT (FUTURE TOKYO)
Rain pours on a dark, wet roof reflecting neon signs. KAI (20s, dressed in a sleek charcoal leather coat with glowing teal neon seams) runs across the metallic grid.

He holds a silver encrypted digital container tightly in his hand.

Behind him, a metallic security patrol drone with scanning red lasers floats quietly down from the clouds, searching the area.

KAI leaps off the edge towards an adjacent balcony. Fade in.`
  },
  {
    title: "Desert Monolith (Sci-Fi)",
    style: "3D Render" as VisualStyle,
    text: `EXT. ENDLESS SAND DUNES - SUNSET
A warm, amber sun sits low on the horizon, casting long shadows over massive red sand dunes.

ALERA (30s, helmeted astronaut in a dusty, worn white spacesuit) climbs over the crest of a steep dune. She shields her eyes against the glare.

Directly in front of her is a giant, perfectly smooth obsidian monolith rising out of the sand, pulsing with soft gold markings.

Alera approaches slowly and reaches out with a gloved hand to touch the black reflective surface. Cut to:`
  },
  {
    title: "The Tiny Alchemist (Fantasy)",
    style: "Watercolor" as VisualStyle,
    text: `INT. CANDLE-LIT EXPERIMENT ROOM - NIGHT
Warm candlelight illuminates a cozy, small fantasy library with shelves overflowing with scrolls, crystals, and vintage brass instruments.

ELODIA (a small forest fairy with shiny, colorful iridescent glass wings) is hovering above a rustic wooden table.

She holds a delicate glass eyedropper and drops a tiny glowing blue drop of liquid into an antique glass beaker.

A brilliant burst of harmless golden sparkles erupts from the beaker, lighting up her face in pure awe.`
  }
];

export default function ScriptUpload({ onParseScript, isLoading }: ScriptUploadProps) {
  const [scriptText, setScriptText] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<VisualStyle>('Cinematic');
  const [selectedSize, setSelectedSize] = useState<ImageSize>('1K');
  const [selectedRatio, setSelectedRatio] = useState<AspectRatio>('16:9');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scriptText.trim() || isLoading) return;
    onParseScript(scriptText, selectedStyle, selectedSize, selectedRatio);
  };

  const loadSample = (sample: typeof SAMPLE_SCRIPTS[0]) => {
    setScriptText(sample.text);
    setSelectedStyle(sample.style);
  };

  return (
    <div id="script-upload-card" className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2.5 bg-amber-500/10 text-amber-500 rounded-xl">
          <Film className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-zinc-100">Upload Script</h2>
          <p className="text-xs text-slate-500">Provide an original story description or screenplay to parse scenes.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="script-textarea" className="block text-xs font-semibold text-slate-400 mb-2">
            Screenplay / Script Text
          </label>
          <textarea
            id="script-textarea"
            rows={8}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs md:text-sm text-zinc-100 placeholder:text-slate-600 outline-none focus:border-amber-500/50 resize-y font-mono"
            placeholder="Paste your screenplay here (including scene actions, sound cues, camera descriptions, dialog)..."
            value={scriptText}
            onChange={(e) => setScriptText(e.target.value)}
          />
        </div>

        {/* Configurations */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-950/40 p-4 rounded-xl border border-slate-850">
          {/* Visual Style Selection */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Scenic Illustration Style
            </span>
            <select
              value={selectedStyle}
              onChange={(e) => setSelectedStyle(e.target.value as VisualStyle)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 px-3 text-xs text-zinc-300 outline-none focus:border-amber-500/50 cursor-pointer"
            >
              <option value="Cinematic">Cinematic (Default)</option>
              <option value="Anime Sketch">Anime Sketch</option>
              <option value="Comic Book Line-Art">Comic Book Line-Art</option>
              <option value="3D Render">3D Render</option>
              <option value="Watercolor">Watercolor</option>
              <option value="Moody Noir">Moody Noir</option>
            </select>
          </div>

          {/* Image Size Selection (Affordance, e.g., 1K, 2K, 4K) */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Resolution (1K, 2K, 4K)
            </span>
            <div className="grid grid-cols-3 gap-1">
              {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                <button
                  type="button"
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                    selectedSize === size
                      ? 'bg-amber-500 text-slate-950 border-amber-500'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-850'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Scenic Aspect Ratio
            </span>
            <select
              value={selectedRatio}
              onChange={(e) => setSelectedRatio(e.target.value as AspectRatio)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 px-3 text-xs text-zinc-300 outline-none focus:border-amber-500/50 cursor-pointer"
            >
              <option value="16:9">Landscape (16:9)</option>
              <option value="1:1">Square (1:1)</option>
              <option value="4:3">Card Standard (4:3)</option>
              <option value="3:2">Classic Photo (3:2)</option>
              <option value="9:16">Vertical Mobile (9:16)</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading || !scriptText.trim()}
          className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg active:scale-[0.99] text-xs md:text-sm"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-slate-950/45 border-t-slate-950 rounded-full animate-spin" />
              <span>Analyzing Drama & Compiling Visual Beats...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 md:w-5 md:h-5" />
              <span>Convert Script to Storyboard</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </>
          )}
        </button>
      </form>

      {/* Preset Script Library */}
      <div className="space-y-3 pt-3 border-t border-slate-850">
        <h3 className="text-xs font-semibold text-slate-400 flex items-center gap-2">
          <FileText className="w-4 h-4 text-amber-500" />
          Quick-Start Sample Script Library
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {SAMPLE_SCRIPTS.map((sample, index) => (
            <button
              key={index}
              type="button"
              onClick={() => loadSample(sample)}
              className="text-left text-xs bg-slate-950/60 hover:bg-slate-950 border border-slate-850 hover:border-amber-500/30 p-2.5 rounded-xl text-slate-300 transition-all font-medium"
            >
              {sample.title}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
